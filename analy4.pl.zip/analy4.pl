#!/usr/bin/perl

$tp = 1;
$sl = -1;
%data = ();

@csvs = glob "./data/*.csv";
for $csv ( @csvs ) {
	$day = $1 if ( $csv =~ /AUDJPY_(\d+)\.csv/ );
	&read_csv();
}

foreach $day ( sort keys %data ) {
	print "$day";
	printf(  ",%.3f", $data{ $day }{ ST } );
	printf(  ",%.3f", $data{ $day }{ HI } );
	printf(  ",%.3f", $data{ $day }{ LO } );
	printf(  ",%.3f", $data{ $day }{ CL } );
	print "\n";
}


#
#
# Sub.
#
#

sub read_csv() {
	open ( IN, $csv ) || die "Can't open $csv.\n";
	$a = 1;
	$m = 0;
	while ( $l = <IN> ) {
		chomp $l;
		$m = 1 if ( $l =~ / 08:05:/ );
		if ( $l =~ /^\d\d/ ) {
			( $da, $bo, $bh, $bl, $bc ) = split ( /,/, $l ); 
			&start_rate() if ( $m == 1 );
			&gain_rate()  if ( $m == 2 );
		}
		$m = 0 if ( $l =~ / 04:59:/ );
		$a++;
	}
	close ( IN );
}


sub start_rate() {
	$data{ $day }{ ST } = $bo;
	$data{ $day }{ HI } = $bh;
	$data{ $day }{ LO } = $bl;
	$data{ $day }{ CL } = $bc;
	$m = 2;
}

sub gain_rate() {
	$data{ $day }{ HI } = $bh if ( $bh > $data{ $day }{ HI } );
	$data{ $day }{ LO } = $bl if ( $bl < $data{ $day }{ LO } );
	$data{ $day }{ CL } = $bc;
}

__END__

