$('#mytable').exTableFilter({
    filters : {
        1 : {
            append : {
                to : 'div.qty-filter-area',
                type : 'text'
            }
        },
        2 : {
            append : {
                to : 'div.radio-filter-area',
                type : 'radio'
            }
        },
        3 : {
            element : 'input.qty-filter',
            onFiltering : function(api){
                return api.getCurrentCellNum() >= api.getCurrentFilterNum();
            }
        }
    }
});
