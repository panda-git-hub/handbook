( lineMax => {
    window.addEventListener( "DOMContentLoaded" , ()=> {
        const content = '.lnumber:before{content:"' + ( () => {
            const buf = [];
            for( let i = 1 ; i <= lineMax ; i ++ ) buf.push( i.toString() );
            return buf;
        })(  ).join( "\\a " ) + '";}';
 
        const styleTag = document.createElement("style");
        styleTag.innerHTML = content;
        document.getElementsByTagName("head")[0].appendChild(styleTag);
    });
})( 300 );